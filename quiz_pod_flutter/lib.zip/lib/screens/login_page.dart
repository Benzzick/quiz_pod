import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:serverpod_auth_idp_flutter/serverpod_auth_idp_flutter.dart';

import '../main.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sign In'),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(
                Icons.quiz,
                size: 80,
                color: Colors.blue,
              ),
              const SizedBox(height: 16),
              const Text(
                'Welcome to QuizPod',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 32),
              SignInWidget(
                client: client,
                emailSignInWidget: EmailSignInWidget(
                  client: client,
                  // Change the initial screen to start registration
                  startScreen: EmailFlowScreen.startRegistration,
                  onAuthenticated: () {
                    Get.to(MyHomePage(title: 'QuizPod Home'));
                  },
                  onError: (error) {
                    Get.showSnackbar(
                      GetSnackBar(
                        messageText: Text('Error: $error'),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
